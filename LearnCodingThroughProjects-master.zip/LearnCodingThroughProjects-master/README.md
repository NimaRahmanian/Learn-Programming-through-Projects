# LearnCodingThroughProjects
Skip the boring, basic programming tutorials and visit these examples to learn Python, C++, Java and HLA Assembly through projects where concepts are used in practical applications. Learn coding through projects, not memorization.
